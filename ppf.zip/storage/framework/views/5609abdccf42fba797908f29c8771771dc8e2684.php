<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h4>
    Welcome ,
    <small><?php echo e(Auth::user()->name); ?>!!</small>
  </h4>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
  </ol>
</section>
<section class="content">
  <!-- Small boxes (Stat box) -->
  <div class="row">
    <div class="col-lg-4 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3><?php echo e($totalClients->count()); ?></h3>

          <p>Total clients</p>
        </div>
        <div class="icon">
          <i class="fa fa-users"></i>
        </div>
        <a href="<?php echo e(route('dashboard.clients.list')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-4 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
          <h3><?php echo e($thisMonthClients->count()); ?></h3>

          <p>Clients registered in <?php echo e(\Carbon\Carbon::now()->format('F Y')); ?></p>
        </div>
        <div class="icon">
          <i class="fa fa-users"></i>
        </div>
        <a href="<?php echo e(route('dashboard.clients.registered_this_month')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-4 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-yellow">
        <div class="inner">
          <h3><?php echo e($thisMonthExpiringAccounts->count()); ?></h3>

          <p>Accounts expiring in <?php echo e(\Carbon\Carbon::now()->format('F Y')); ?></p>
        </div>
        <div class="icon">
          <i class="fa fa-rupee"></i>
        </div>
        <a href="<?php echo e(route('dashboard.clients.accounts.expiring_accounts_this_month')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
  </div>
  <!-- /.row -->

  <div class="row">
    <!-- Recent Accounts -->
    <div class="col-md-6">

      <!-- TABLE: LATEST ORDERS -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Recent Accounts</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example2" class="table no-margin">
              <thead>
                <tr>
                  <th>Start Date</th>
                  <th>Name</th>
                  <th>Phone No</th>
                  <th>Amount Received</th>
                  <th>Interest Rate</th>
                  <th>Tenure</th>
                  <th>View</th>
                </tr>
              </thead>
              <tbody>
                <?php if($recentAccounts->count() > 0): ?>

                <?php $__currentLoopData = $recentAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($recentAccount->start_date); ?></td>
                  <td><?php echo e($recentAccount->client->client_full_name); ?></td>
                  <td><?php echo e($recentAccount->client->client_phone_number); ?></td>
                  <td><?php echo e($recentAccount->amount_received); ?></td>
                  <td><?php echo e($recentAccount->interest_rate); ?> %</td>
                  <td><?php echo e($recentAccount->tenure_display); ?></td>
                  <td>
                    <a href="<?php echo e(route('dashboard.clients.accounts.passbook.show',['clientSlug'=> $recentAccount->client->slug,'accountSlug'=> $recentAccount->slug])); ?>"><span class="label label-primary"><i class="glyphicon glyphicon-eye-open"></i></span></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                <tr>
                  <th colspan="5" class="text-center">No Recent Accounts</th>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <!-- /.table-responsive -->
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
    <!-- Expiring Accounts -->
    <div class="col-md-6">

      <!-- TABLE: LATEST ORDERS -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Expiring Accounts</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example2" class="table no-margin">
              <thead>
                <tr>
                  <th>End Date</th>
                  <th>Name</th>
                  <th>Phone No</th>
                  <th>Days Left</th>
                  <th>View</th>
                </tr>
              </thead>
              <tbody>
                <?php if($expiringAccounts->count() > 0): ?>

                <?php $__currentLoopData = $expiringAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expiringAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $expiringAccountEndDate = $expiringAccount->end_date;
                $expiringAccountCurrentDate = date("Y-m-d");
                $expiringAccountEndDateTime = new DateTime($expiringAccountEndDate);
                $expiringAccountCurrentDateTime = new DateTime($expiringAccountCurrentDate);
                $expiringAccountInterval = $expiringAccountEndDateTime->diff($expiringAccountCurrentDateTime);
                $expiringAccountDaysLeft = $expiringAccountInterval->format('%a');
                ?>
                <tr>
                  <td><?php echo e($expiringAccount->end_date); ?></td>
                  <td><?php echo e($expiringAccount->client->client_full_name); ?></td>
                  <td><?php echo e($expiringAccount->client->client_phone_number); ?></td>
                  <td><span class="label label-success"><?php echo e($expiringAccountDaysLeft); ?></span></td>
                  <td>
                    <a href="<?php echo e(route('dashboard.clients.accounts.passbook.show',['clientSlug'=> $expiringAccount->client->slug,'accountSlug'=> $expiringAccount->slug])); ?>"><span class="label label-primary"><i class="glyphicon glyphicon-eye-open"></i></span></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                <tr>
                  <th colspan="5" class="text-center">No Expiring Accounts</th>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <!-- /.table-responsive -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer clearfix">
          <a href="<?php echo e(route('dashboard.clients.accounts.expiring_accounts_list')); ?>" class="btn btn-sm btn-primary btn-flat pull-left">View All Expiring Accounts</a>
        </div>
        <!-- /.box-footer -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
  <div class="row">
    <!-- Elapsing Accounts -->
    <div class="col-md-6">

      <!-- TABLE: LATEST ORDERS -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Elapsing Accounts</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example2" class="table no-margin">
              <thead>
                <tr>
                  <th>Pay Date</th>
                  <th>Name</th>
                  <th>Phone No</th>
                  <th>Interest Amount</th>
                  <th>Days Left</th>
                  <th>View</th>
                </tr>
              </thead>
              <tbody>
                <?php if($elapsingAccounts->count() > 0): ?>

                <?php $__currentLoopData = $elapsingAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elapsingAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $elapsingAccountNextDate = \Carbon\Carbon::parse($elapsingAccount->next_date)->subDays(1)->format('Y-m-d');
                $elapsingAccountCurrentDate = date("Y-m-d");
                $elapsingAccountNextDateTime = new DateTime($elapsingAccountNextDate);
                $elapsingAccountCurrentDateTime = new DateTime($elapsingAccountCurrentDate);
                $elapsingAccountInterval = $elapsingAccountNextDateTime->diff($elapsingAccountCurrentDateTime);
                $elapsingAccountDaysLeft = $elapsingAccountInterval->format('%a');
                ?>
                <tr>
                  <td><?php echo e(\Carbon\Carbon::parse($elapsingAccount->next_date)->subDays(1)->format('Y-m-d')); ?></td>
                  <td><?php echo e($elapsingAccount->client->client_full_name); ?></td>
                  <td><?php echo e($elapsingAccount->client->client_phone_number); ?></td>
                  <td><?php echo e($elapsingAccount->interest_amount); ?></td>
                  <td><span class="label label-success"><?php echo e($elapsingAccountDaysLeft); ?></span></td>
                  <td>
                    <a href="<?php echo e(route('dashboard.clients.accounts.passbook.show',['clientSlug'=> $elapsingAccount->client->slug,'accountSlug'=> $elapsingAccount->slug])); ?>"><span class="label label-primary"><i class="glyphicon glyphicon-eye-open"></i></span></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                <tr>
                  <th colspan="5" class="text-center">No Elapsinng Accounts</th>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <!-- /.table-responsive -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer clearfix">
          <a href="<?php echo e(route('dashboard.clients.accounts.elapsing_accounts_list')); ?>" class="btn btn-sm btn-primary btn-flat pull-left">View All Elapsing Accounts</a>
        </div>
        <!-- /.box-footer -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
    <!-- Elapsing Commissions -->
    <div class="col-md-6">

      <!-- TABLE: LATEST ORDERS -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Elapsing Commissions</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example2" class="table no-margin">
              <thead>
                <tr>
                  <th>Pay Date</th>
                  <th>Name</th>
                  <th>Referred By</th>
                  <th>Commission Amount</th>
                  <th>Days Left</th>
                  <th>View</th>
                </tr>
              </thead>
              <tbody>
                <?php if($elapsingCommissions->count() > 0): ?>

                <?php $__currentLoopData = $elapsingCommissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elapsingCommission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $elapsingCommissionNextDate = \Carbon\Carbon::parse($elapsingCommission->next_date)->subDays(1)->format('Y-m-d');
                $elapsingCommissionCurrentDate = date("Y-m-d");
                $elapsingCommissionNextDateTime = new DateTime($elapsingCommissionNextDate);
                $elapsingCommissionCurrentDateTime = new DateTime($elapsingCommissionCurrentDate);
                $elapsingCommissionInterval = $elapsingCommissionNextDateTime->diff($elapsingCommissionCurrentDateTime);
                $elapsingCommissionDaysLeft = $elapsingCommissionInterval->format('%a');
                ?>
                <tr>
                  <td><?php echo e(\Carbon\Carbon::parse($elapsingCommission->next_date)->subDays(1)->format('Y-m-d')); ?></td>
                  <td><?php echo e($elapsingCommission->client->client_full_name); ?></td>
                  <td><?php echo e($elapsingCommission->client->referred_by); ?></td>
                  <td><?php echo e($elapsingCommission->commission_amount); ?></td>
                  <td><span class="label label-success"><?php echo e($elapsingCommissionDaysLeft); ?></span></td>
                  <td>
                    <a href="<?php echo e(route('dashboard.clients.accounts.passbook.show',['clientSlug'=> $elapsingCommission->client->slug,'accountSlug'=> $elapsingCommission->slug])); ?>"><span class="label label-primary"><i class="glyphicon glyphicon-eye-open"></i></span></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                <tr>
                  <th colspan="5" class="text-center">No Elapsing Commissions</th>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <!-- /.table-responsive -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer clearfix">
          <a href="<?php echo e(route('dashboard.clients.accounts.elapsing_commissions_list')); ?>" class="btn btn-sm btn-primary btn-flat pull-left">View All Elapsing Commissions</a>
        </div>
        <!-- /.box-footer -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppf\resources\views/home.blade.php ENDPATH**/ ?>