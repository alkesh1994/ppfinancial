<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
<h1>Passbook</h1>
  <table id="customers">
      <tr>
        <th>Date</th>
        <th>Base Amt</th>
        <th>Tenure</th>
        <th>Interest %</th>
        <th>Interest Amt</th>
        <th>Current Amt</th>
        <th>Total Amt</th>
        <th>W/D Date</th>
        <th>W/D Amt</th>
        <th>Penalty</th>
        <th>Referred By</th>
        <th>Comm Type</th>
        <th>Comm %</th>
        <th>Comm Amt</th>
        <th>Comm Total Amt</th>
      </tr>
      <?php $__currentLoopData = $passbookEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passbookEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($passbookEntry->date); ?></td>
        <td><?php echo e($passbookEntry->base_amount); ?></td>
        <td><?php echo e($passbookEntry->tenure); ?></td>
        <td><?php echo e($passbookEntry->interest_rate); ?></td>
        <td><?php echo e($passbookEntry->interest_amount); ?></td>
        <td><?php echo e($passbookEntry->current_amount); ?></td>
        <td><?php echo e($passbookEntry->total_amount); ?></td>
        <td><?php echo e($passbookEntry->withdrawn_date); ?></td>
        <td><?php echo e($passbookEntry->withdrawn_amount); ?></td>
        <td><?php echo e($passbookEntry->penalty); ?></td>
        <td><?php echo e($passbookEntry->account->client->referred_by); ?></td>
        <td>
          <?php if($passbookEntry->account->commission_type == 1): ?>
           Monthly
          <?php elseif($passbookEntry->account->commission_type == 2): ?>
           OneTime
          <?php else: ?>
           N.A
          <?php endif; ?>
        </td>
        <td><?php echo e($passbookEntry->commission_percentage); ?></td>
        <td><?php echo e($passbookEntry->commission_amount); ?></td>
        <td><?php echo e($passbookEntry->commission_total_amount); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ppf\resources\views/dashboard/client/account/passbook/exportPassbookPdf.blade.php ENDPATH**/ ?>