

<?php $__env->startSection('content'); ?>

<section class="content-header">
  <h1>
    Expiring Accounts List

  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(route('dashboard.clients.list')); ?>"><i class="fa fa-dashboard"></i> Clients</a></li>
    <li class="active">Accounts</li>
  </ol>
</section>
<!-- account list begin -->
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <!-- /.box-header -->
      <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Expiring Accounts List</h3>
        </div>
        <div class="box-body table-responsive ">

          <table id="tablelist" class="display">
            <thead>
              <tr>
                <th>End Date</th>
                <th>Name</th>
                <th>Phone No</th>
                <th>Days Left</th>
                <th>View</th>
              </tr>
            </thead>

            <?php if($accounts->count() > 0): ?>
            <?php $i=0; ?>
            <tbody>
              <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
              $i++;
              $expiringAccountEndDate = $account->end_date;
              $expiringAccountCurrentDate = date("Y-m-d");
              $expiringAccountEndDateTime = new DateTime($expiringAccountEndDate);
              $expiringAccountCurrentDateTime = new DateTime($expiringAccountCurrentDate);
              $expiringAccountInterval = $expiringAccountEndDateTime->diff($expiringAccountCurrentDateTime);
              $expiringAccountDaysLeft = $expiringAccountInterval->format('%a');
              ?>

              <tr>
                <td><?php echo e($account->end_date); ?></td>
                <td><?php echo e($account->client->client_full_name); ?></td>
                <td><?php echo e($account->client->client_phone_number); ?> ₹</td>
                <td><span class="label label-success"><?php echo e($expiringAccountDaysLeft); ?></span></td>
                <td>
                  <a href="<?php echo e(route('dashboard.clients.accounts.passbook.show',['clientSlug'=> $account->client->slug,'accountSlug'=> $account->slug])); ?>" title="Passbook"><span class="label label-success"><i class="glyphicon glyphicon-list-alt"></i></span></a>
                </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                <tr>
                  <th>End Date</th>
                  <th>Name</th>
                  <th>Phone No</th>
                  <th>Days Left</th>
                  <th></th>
                </tr>
              </tfoot>
              <?php else: ?>
              <tbody>
                <tr>

                  <th colspan="7" class="text-center">No account to be expired yet</th>

                </tr>
              </tbody>
              <?php endif; ?>
            </table>

          </div>
          <!-- /.box-body -->
        </div>
      </div>
      <!-- /.box -->
    </div>
  </div>
</section>
<!-- account list end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- DataTables -->
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script>

$(document).ready(function() {
  // Setup - add a text input to each footer cell
  var set = $('#tablelist tfoot th');
  var length = set.length;
  $('#tablelist tfoot th').each(function (index,element) {
    if (index<(length-1)) {
      var title = $(this).text();
      $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    }

  } );

  // DataTable
  var table = $('#tablelist').dataTable({
    "order": [],
    "autoWidth": true,
    columnDefs: [ { orderable: false, targets: [2,4] } ]
  });

  // Apply the search
  table.columns().every( function () {
    var that = this;

    $( 'input', this.footer() ).on( 'keyup change clear', function () {
      if ( that.search() !== this.value ) {
        that
        .search( this.value )
        .draw();
      }
    } );
  } );
  $('#tablelist tfoot tr').appendTo('#tablelist thead');
} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppf\resources\views/dashboard/client/account/expiringAccountsList.blade.php ENDPATH**/ ?>