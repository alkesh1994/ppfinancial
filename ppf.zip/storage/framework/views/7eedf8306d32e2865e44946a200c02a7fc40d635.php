

<?php $__env->startSection('content'); ?>

<section class="content-header">
  <h1>
    Client : <?php echo e($client->client_full_name); ?> | Account : <?php echo e(\Carbon\Carbon::parse($account->start_date)->format('j F Y')); ?> to <?php echo e(\Carbon\Carbon::parse($account->end_date)->format('j F Y')); ?>


  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(route('dashboard.clients.list')); ?>"><i class="fa fa-dashboard"></i> Clients</a></li>
    <li><a href="<?php echo e(route('dashboard.clients.accounts.list',['slug'=> $client->slug])); ?>"><i class="fa fa-dashboard"></i> Accounts</a></li>
    <li class="active">Passbook</li>
  </ol>
</section>
<!-- passbook list begin -->
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <!-- /.box-header -->
      <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Passbook Entries</h3>
        </div>
        <div class="box-body table-responsive ">

          <table id="tablelist" class="display">
            <thead>
              <tr>
                <th>Date(Entry)</th>
                <th>Base Amount(₹)</th>
                <th>Tenure(months)</th>
                <th>Interest %</th>
                <th>Interest Amount(₹)</th>
                <th>Current Amount(₹)</th>
                <th>Total Amount(₹)</th>
                <th>Withdrawn Date</th>
                <th>Withdrawn Amount(₹)</th>
                <th>Penalty(₹)</th>
                <th>Referred By</th>
                <th>Commission Type</th>
                <th>Commission %</th>
                <th>Commision Amt(₹)</th>
                <th>Commission Total Amt(₹)</th>
              </tr>
            </thead>

            <?php if($passbookEntries->count() > 0): ?>
            <?php $i=0; ?>
            <tbody>
              <?php $__currentLoopData = $passbookEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passbookEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $i++; ?>

              <tr>
                <td><?php echo e($passbookEntry->date); ?></td>
                <td><?php echo e($passbookEntry->base_amount); ?></td>
                <td><?php echo e($passbookEntry->tenure); ?></td>
                <td><?php echo e($passbookEntry->interest_rate); ?></td>
                <td><?php echo e($passbookEntry->interest_amount); ?></td>
                <td><?php echo e($passbookEntry->current_amount); ?></td>
                <td><?php echo e($passbookEntry->total_amount); ?></td>
                <td><?php echo e($passbookEntry->withdrawn_date); ?></td>
                <td><?php echo e($passbookEntry->withdrawn_amount); ?></td>
                <td><?php echo e($passbookEntry->penalty); ?></td>
                <td><?php echo e($passbookEntry->account->client->referred_by); ?></td>
                <td>
                  <?php if($passbookEntry->account->commission_type == 1): ?>
                   Monthly
                  <?php elseif($passbookEntry->account->commission_type == 2): ?>
                   OneTime
                  <?php else: ?>
                   N.A
                  <?php endif; ?>
                </td>
                <td><?php echo e($passbookEntry->commission_percentage); ?></td>
                <td><?php echo e($passbookEntry->commission_amount); ?></td>
                <td><?php echo e($passbookEntry->commission_total_amount); ?></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                <tr>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
              </tfoot>
              <?php else: ?>
              <tbody>
                <tr>

                  <th colspan="7" class="text-center">No passbook created yet</th>

                </tr>
              </tbody>
              <?php endif; ?>
            </table>

          </div>
          <!-- /.box-body -->
        </div>
      </div>
      <!-- /.box -->
    </div>
  </div>
</section>
<!-- account list end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- DataTables -->
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script>

$(document).ready(function() {

  // DataTable
  var table = $('#tablelist').dataTable({
    "order": [],
    "autoWidth": true,
    columnDefs: [ { orderable: false, targets: [2,10] } ]
  });

} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppf\resources\views/dashboard/client/account/passbook/show.blade.php ENDPATH**/ ?>