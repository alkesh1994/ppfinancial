<?php

return [

    'model_namespace' => '\\App\\Models\\'
]

?>
